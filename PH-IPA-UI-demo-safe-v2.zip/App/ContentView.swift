import SwiftUI

@main
struct PHIPADemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "iphone.gen3")
                    .font(.system(size: 54, weight: .light))
                    .foregroundStyle(.blue)
                Text("PH iOS UI Demo")
                    .font(.largeTitle.bold())
                Text("Demonstração somente de interface. Não executa exploits, não altera outros apps e não acessa dados fora deste app.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
                Label("Modo seguro — interface somente", systemImage: "checkmark.shield.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.green)
                    .padding(.top, 8)
                Spacer()
            }
            .padding(.top, 64)
            .navigationTitle("PH IPA Demo")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
