# PH iOS UI Demo — projeto seguro

Demo pequena de interface SwiftUI. Não contém exploit de kernel, escape de sandbox, escalonamento de privilégio, bypass de detecção de jailbreak nem download remoto de código.

## API

O contrato atual de validação de licença, exemplos de requisição, respostas e limitações de compatibilidade está em [`API_INTEGRATION.md`](API_INTEGRATION.md). A demo atual **não chama a API**; o documento é referência para uma integração futura autorizada pelo backend. O Markdown acompanha o projeto-fonte e não é incorporado ao binário IPA.

## Compilação

O workflow de GitHub Actions é manual (`workflow_dispatch`) e produz uma IPA sem assinatura como artifact, retido por sete dias. Não cria uma GitHub Release.

Para gerar o projeto Xcode localmente em macOS, instale XcodeGen e execute:

```bash
xcodegen generate --spec project.yml
```

Depois compile o scheme `PHIPADemo` pelo Xcode.
