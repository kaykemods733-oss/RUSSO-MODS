# Projeto da API

Projeto completo da API Railway, painel administrativo, routers, schema Drizzle, testes e documentação.

Comandos principais dentro de `ph/`:

```bash
pnpm install --frozen-lockfile
pnpm run build
```

Não há credenciais ou arquivo `.env` incluídos neste pacote.
