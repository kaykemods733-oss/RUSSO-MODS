# PH iOS UI Demo (safe)

This is a small SwiftUI demonstration app. It contains no kernel exploit, sandbox escape, privilege escalation, jailbreak-detection bypass, or remote code downloads.

## Build

The GitHub Actions workflow is **manual-only** (`workflow_dispatch`) and creates an unsigned IPA artifact retained for seven days. It does not publish a GitHub Release. Run it from the Actions tab after importing this directory into a repository.

To generate the Xcode project locally on macOS: install XcodeGen, run `xcodegen generate --spec project.yml`, then build the `PHIPADemo` scheme with Xcode.
